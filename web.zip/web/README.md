# RCS-RepVGG-Enhanced-YOLO-Wildfire-Smoke-Detection

![Python](https://img.shields.io/badge/python-3.8+-blue.svg)
![PyTorch](https://img.shields.io/badge/PyTorch-1.7+-red.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

## 🚀 项目简介 | Project Overview

本项目是基于 YOLO 的高级目标检测框架，集成了多种先进的网络架构优化技术，包括 RepVGG 重参数化技术、RCSOSA(Residual Cross-Stage Optimized Spatial Attention)模块和 SimAM(Simple Attention Module)注意力机制。项目专注于烟火检测任务，提供了 8 种不同的模型配置以满足不同精度和速度要求。

## ✨ 主要特性 | Key Features

- 🔥 **8 种优化模型架构**: 基础版、RepVGG、RCSOSA、SimAM 及其组合变体
- 📊 **智能数据集分析**: 自动生成详细的数据集统计报告
- 🎯 **专优超参数配置**: 针对烟火检测任务优化的超参数设置
- 📈 **完整可视化工具**: 支持架构图、训练曲线、检测结果可视化
- 🛠️ **便捷训练工具**: 简化的训练和测试流程
- 📝 **详细技术文档**: 包含架构解析、参数映射等技术文档

## 📁 项目结构 | Project Structure

```
RCS-RepVGG-Enhanced-YOLO-Wildfire-Smoke-Detection/
├── cfg/                          # 模型配置文件
│   ├── training/                 # 训练配置
│   │   ├── yolov4-csp-IDetect.yaml          # 基础检测头模型
│   │   ├── yolov4-repvgg.yaml               # RepVGG优化版
│   │   ├── yolov4-rcsosa.yaml               # RCSOSA注意力版
│   │   ├── yolov4-simAM.yaml                # SimAM注意力版
│   │   ├── yolov4-repvgg-rcsosa.yaml        # RepVGG+RCSOSA组合
│   │   ├── yolov4-repvgg-simAM.yaml         # RepVGG+SimAM组合
│   │   ├── yolov4-rcsosa-simAM.yaml         # RCSOSA+SimAM组合
│   │   └── yolov4-repvgg-rcsosa-simAM.yaml  # 全功能组合版
│   └── baseline/                 # 基准配置
├── data/                         # 超参数配置文件
│   ├── hyp_training.yaml         # 通用训练超参数
│   ├── hyp.*.yaml               # 模型特定超参数
│   └── *.yaml                   # 数据集配置
├── datasets_smokefire/          # 烟火数据集
│   ├── train/                   # 训练集 (7680张)
│   ├── valid/                   # 验证集 (960张)
│   ├── test/                    # 测试集 (960张)
│   └── data.yaml               # 数据集配置
├── models/                      # 模型定义
├── utils/                       # 工具函数
├── train.py                     # 训练脚本
├── test.py                      # 测试脚本
├── export.py                    # 模型导出
└── inference/                   # 推理相关

```

## 📊 数据集信息 | Dataset Information

### 烟火检测数据集 (SmokeFireDataset)

- **总计**: 9,600 张图像
- **训练集**: 7,680 张 (80%)
- **验证集**: 960 张 (10%)
- **测试集**: 960 张 (10%)
- **类别**: 2 类 (smoke, fire)
- **标注格式**: YOLO 格式

数据集按以下结构放置：

```
datasets_smokefire/
├── train/
│   ├── images/
│   └── labels/
├── valid/
│   ├── images/
│   └── labels/
├── test/
│   ├── images/
│   └── labels/
└── data.yaml
```

### 数据集特点

- ✅ 高质量标注
- ✅ 多场景覆盖（室内外、日夜间）
- ✅ 不同尺度目标
- ✅ 类别平衡优化

## 🎯 训练指南 | Training Guide

```bash
# 基础模型
python train.py --workers 1 --device 0 --batch-size 8 \
    --data datasets_smokefire/data.yaml --img 640 640 \
    --cfg cfg/training/yolov4-csp-IDetect.yaml \
    --weights '' --name yolov4-csp-IDetect \
    --hyp data/hyp.yolov4-csp-idetect-smokefire.yaml

# RepVGG模型
python train.py --workers 1 --device 0 --batch-size 8 \
    --data datasets_smokefire/data.yaml --img 640 640 \
    --cfg cfg/training/yolov4-repvgg.yaml \
    --weights '' --name yolov4-repvgg \
    --hyp data/hyp.yolov4-repvgg-smokefire.yaml

# RCSOSA模型
python train.py --workers 1 --device 0 --batch-size 8 \
    --data datasets_smokefire/data.yaml --img 640 640 \
    --cfg cfg/training/yolov4-rcsosa.yaml \
    --weights '' --name yolov4-rcsosa \
    --hyp data/hyp.yolov4-rcsosa-smokefire.yaml

# 全功能模型
python train.py --workers 1 --device 0 --batch-size 8 \
    --data datasets_smokefire/data.yaml --img 640 640 \
    --cfg cfg/training/yolov4-repvgg-rcsosa-simAM.yaml \
    --weights '' --name yolov4-repvgg-rcsosa-simAM \
    --hyp data/hyp.yolov4-repvgg-rcsosa-simAM-smokefire.yaml
```

### 推理检测

```bash
# 单图像推理
python detect.py --weights runs/train/exp/weights/best.pt \
    --source inference/images/test.jpg --img-size 640 \
    --conf-thres 0.4 --iou-thres 0.5

# 批量推理
python detect.py --weights runs/train/exp/weights/best.pt \
    --source inference/images/ --img-size 640 \
    --conf-thres 0.4 --iou-thres 0.5 --save-txt --save-conf
```

## 🔧 常见问题 | FAQ

### 环境配置问题

**Q: CUDA 版本不匹配怎么办？**
A: 检查 PyTorch 和 CUDA 版本兼容性，建议使用 CUDA 11.1+配合 PyTorch 1.7+

**Q: 内存不足错误？**
A: 降低 batch-size，或使用更小的输入尺寸（如 512x512）

### 训练问题

**Q: 损失不收敛？**
A: 检查学习率设置，尝试降低初始学习率或使用预训练权重

**Q: mAP 很低？**
A: 确认数据集标注质量，调整 NMS 阈值和 confidence 阈值

### 推理问题

**Q: 检测效果差？**
A: 调整 conf-thres 和 iou-thres 参数，或尝试 TTA（测试时增强）

## 📖 参考文献 | References

1. Wang, C. Y., Bochkovskiy, A., & Liao, H. Y. M. (2023). YOLOv7: Trainable bag-of-freebies sets new state-of-the-art for real-time object detectors.
2. Ding, X., Zhang, X., Ma, N., Han, J., Ding, G., & Sun, J. (2021). RepVGG: Making VGG-style ConvNets Great Again.
3. Yang, L., Zhang, R. Y., Li, L., & Xie, X. (2021). SimAM: A Simple, Parameter-Free Attention Module for Convolutional Neural Networks.

## 🤝 贡献指南 | Contributing

欢迎提交 Issue 和 Pull Request 来改进项目！

### 贡献流程

1. Fork 本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📄 许可证 | License

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 🙏 致谢 | Acknowledgments

- YOLOv7 原始项目团队
- PyTorch 社区
- 数据集标注团队
- 所有为本项目做出贡献的开发者

---

**⭐ 如果这个项目对您有帮助，请给我们一个 Star！**
