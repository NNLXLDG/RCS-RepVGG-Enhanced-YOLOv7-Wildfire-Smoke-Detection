#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YOLOv7烟火检测项目网页服务器
HTTP服务器，用于本地预览项目网页
"""

import http.server
import socketserver
import webbrowser
import os
import sys
from pathlib import Path

def start_server(port=8080):
    """
    启动HTTP服务器
    
    Args:
        port (int): 服务器端口号，默认8080
    """
    # 确保在正确的目录下运行
    script_dir = Path(__file__).parent
    os.chdir(script_dir)
    
    # 检查index.html是否存在
    if not Path('index.html').exists():
        print("❌ 错误: 未找到index.html文件")
        print("请确保在包含index.html的目录中运行此脚本")
        return
    
    # 创建HTTP请求处理器
    class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
        def end_headers(self):
            # 添加CORS头部，允许跨域访问
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            super().end_headers()
        
        def log_message(self, format, *args):
            # 自定义日志格式
            print(f"📄 {self.address_string()} - {format % args}")
    
    try:
        # 尝试启动服务器
        with socketserver.TCPServer(("", port), CustomHTTPRequestHandler) as httpd:
            server_url = f"http://localhost:{port}"
            
            print("🚀 YOLOv7烟火检测项目网页服务器启动成功!")
            print(f"📍 服务器地址: {server_url}")
            print(f"📁 服务目录: {script_dir}")
            print("\n🌟 项目功能:")
            print("   • 项目介绍 - YOLOv7增强版烟火检测系统")
            print("   • 数据集分析 - 数据分布和增强技术")
            print("   • 模型创新 - RepVGG、RCSOSA、SimAM技术")
            print("   • 训练结果 - 8个模型的完整对比")
            print("   • 最优模型 - 性能分析和应用前景")
            print("   • 推理演示 - 图像和视频检测效果")
            print("\n💡 使用说明:")
            print("   • 点击选项卡切换不同功能模块")
            print("   • 点击图片可放大查看详细内容")
            print("   • 在训练结果页面可选择不同模型查看")
            print("   • 性能对比表格按F1分数自动排序")
            print("\n⌨️  按 Ctrl+C 停止服务器")
            print("="*60)
            
            # 自动打开浏览器
            try:
                webbrowser.open(server_url)
                print(f"🌐 已自动打开浏览器: {server_url}")
            except Exception as e:
                print(f"⚠️  无法自动打开浏览器: {e}")
                print(f"请手动访问: {server_url}")
            
            print("\n🔄 服务器运行中...")
            
            # 启动服务器
            httpd.serve_forever()
            
    except OSError as e:
        if e.errno == 48 or "Address already in use" in str(e):
            print(f"❌ 端口 {port} 已被占用")
            print(f"💡 尝试使用其他端口...")
            start_server(port + 1)
        else:
            print(f"❌ 启动服务器失败: {e}")
    except KeyboardInterrupt:
        print("\n\n🛑 服务器已停止")
        print("👋 感谢使用YOLOv7烟火检测项目展示系统!")
    except Exception as e:
        print(f"❌ 意外错误: {e}")

def main():
    """
    主函数
    """
    print("🔥 YOLOv7烟火检测项目网页服务器")
    print("=" * 40)
    
    # 检查命令行参数
    port = 8080
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
            if not (1024 <= port <= 65535):
                print("⚠️  端口号应在1024-65535范围内，使用默认端口8080")
                port = 8080
        except ValueError:
            print("⚠️  无效的端口号，使用默认端口8080")
            port = 8080
    
    start_server(port)

if __name__ == "__main__":
    main()